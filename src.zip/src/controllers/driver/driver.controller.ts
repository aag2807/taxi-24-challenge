import { Controller, Get } from '@nestjs/common';
import { DriverRepository } from '../../boundaries/persistance/repositories/driver/driver.repository';

@Controller('driver')
export class DriverController {

  constructor(private driverRepository: DriverRepository) {
  }

  @Get()
  public async getDrivers() {
    return await this.driverRepository.readAll();
  }
}

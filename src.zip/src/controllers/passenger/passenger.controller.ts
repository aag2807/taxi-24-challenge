import { Controller } from '@nestjs/common';

@Controller('passenger')
export class PassengerController {}

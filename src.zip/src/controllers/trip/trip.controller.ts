import { Controller } from '@nestjs/common';

@Controller('trip')
export class TripController {}

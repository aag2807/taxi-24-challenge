import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne, OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Driver } from '../../driver/models/driver.entity';
import { Passenger } from '../../passenger/models/passenger.entity';
import { Invoice } from '../../invoice/models/invoice.entity';
import { Nullable } from '../../../common/types/common.types';
import { TripStatus } from '../types/trip-status.type';

@Entity('trips')
export class Trip {
  @PrimaryGeneratedColumn()
  public tripId: number;

  @ManyToOne(() => Passenger, passenger => passenger.trips)
  @JoinColumn({ name: 'passengerId' })
  public passenger: Passenger;

  @ManyToOne(() => Driver, driver => driver.trips)
  @JoinColumn({ name: 'driverId' })
  public driver: Driver;

  @Column({ type: 'varchar', length: 255, nullable: true })
  public startLocation: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  public endLocation: string;

  @CreateDateColumn()
  public startTime: Date;

  @UpdateDateColumn({ nullable: true })
  public endTime: Date;

  @Column({ length: 25, type: 'varchar' })
  public status: Nullable<TripStatus> = '';

  @OneToOne(() => Invoice, invoice => invoice.trip)
  public invoice: Invoice;
}
export default () => ({
  database: {

  }
})